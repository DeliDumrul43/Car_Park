﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Collections;

namespace CSHARPPROJE
{
    public partial class Forgot : Form
    {
        public Forgot()
        {
            InitializeComponent();
        }
        OleDbConnection con;
        OleDbCommand cmd;

        Login login = new Login();

        public void kontrol()
        {
            if (checkBox1.Checked == true)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }

            if (checkBox1.Checked == true)
            {
                textBox3.UseSystemPasswordChar = false;
            }
            else
            {
                textBox3.UseSystemPasswordChar = true;
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {
            

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
        }

        private void label4_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("BOŞ ALAN BIRAKMAYINIZ", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (textBox1.Text == Register.user[3].ToString())
                    {
                        if (textBox2.Text == textBox3.Text)
                        {
                            con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=USERS.mdb");
                            cmd = new OleDbCommand();
                            con.Open();
                            cmd.Connection = con;
                            cmd.CommandText = "update USERS set Kullanici_sifre='" + textBox2.Text + "' where ID=" + Register.user[0] + "";
                            cmd.ExecuteNonQuery();
                            con.Close();

                            MessageBox.Show("Başarı ile değiştirildi LOGIN kısmına aktarılıyorsunuz", "Bildirim", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            login.Show();
                            this.Hide();
                            
                        }
                        else
                        {
                            MessageBox.Show("Şifreler birbiri ile uyuşmuyor", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }


                    }
                    else
                    {
                        MessageBox.Show("Kodlar birbiri ile uyuşmuyor", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }


                }
            }
            catch
            {
                MessageBox.Show("BEKLENMEDİK HATA", "HATA", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            kontrol();

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            kontrol();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            kontrol();

        }

        private void Forgot_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult secenek = MessageBox.Show("Programı kapatmak istiyor musunuz?", "Bilgilendirme Penceresi", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (secenek == DialogResult.No)
            {
                e.Cancel = true;
                return;

            }
            Environment.Exit(0);

        }

        private void Forgot_Load(object sender, EventArgs e)
        {

        }
    }
}
